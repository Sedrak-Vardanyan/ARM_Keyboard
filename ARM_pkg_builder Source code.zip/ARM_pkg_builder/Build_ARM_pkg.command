#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"

APP_NAME="ARM Keyboard"
IDENTIFIER="com.sedrak.armkeyboard"
VERSION="1.0"
PKG_NAME="ARM_Keyboard.pkg"
WORK="build"
PAYLOAD="$WORK/payload"
COMPONENT="$WORK/ARMKeyboardComponent.pkg"

rm -rf "$WORK" "$PKG_NAME"
mkdir -p "$PAYLOAD/Library/Keyboard Layouts" "$WORK"

cp "ARM.keylayout" "$PAYLOAD/Library/Keyboard Layouts/ARM.keylayout"

# Optional icon: put ARM.icns next to this script. If your file is ARM.icons, rename it to ARM.icns first.
if [ -f "ARM.icns" ]; then
  cp "ARM.icns" "$PAYLOAD/Library/Keyboard Layouts/ARM.icns"
elif [ -f "ARM.icons" ]; then
  cp "ARM.icons" "$PAYLOAD/Library/Keyboard Layouts/ARM.icns"
fi

chmod 644 "$PAYLOAD/Library/Keyboard Layouts/ARM.keylayout"
if [ -f "$PAYLOAD/Library/Keyboard Layouts/ARM.icns" ]; then
  chmod 644 "$PAYLOAD/Library/Keyboard Layouts/ARM.icns"
fi
chmod +x scripts/postinstall

pkgbuild \
  --root "$PAYLOAD" \
  --identifier "$IDENTIFIER" \
  --version "$VERSION" \
  --install-location "/" \
  --scripts scripts \
  "$COMPONENT"

productbuild \
  --distribution "Distribution.xml" \
  --resources "Resources" \
  --package-path "$WORK" \
  "$PKG_NAME"

rm -rf "$WORK"

echo ""
echo "✅ Done: $PKG_NAME"
echo "Install it, then log out/in or restart if ARM does not appear immediately in Input Sources."
