ARM Keyboard PKG Builder

Պետք է լինի նույն պապկի մեջ՝
- ARM.keylayout
- ARM.icns կամ ARM.icons  (optional icon)
- Build_ARM_pkg.command
- Distribution.xml
- Resources/
- scripts/

Ինչպես սարքել pkg՝
1. Քո icon ֆայլը դիր այս պապկի մեջ ու անվանիր ARM.icns։ Եթե հիմա ARM.icons է, script-ը էլի կվերցնի ու կտեղադրի որպես ARM.icns։
2. Բացիր Terminal-ը այս պապկի մեջ։
3. Աշխատացրու՝
   chmod +x Build_ARM_pkg.command
   ./Build_ARM_pkg.command
4. Կստանաս՝ ARM_Keyboard.pkg

Տեղադրում՝
- Double click ARM_Keyboard.pkg
- Install
- Հետո System Settings → Keyboard → Text Input / Input Sources → Edit → + → Others → ARM

Եթե ուզում ես ինտերնետով տարածել առանց macOS warning-ի՝ պետք է Apple Developer ID, signing և notarization։
